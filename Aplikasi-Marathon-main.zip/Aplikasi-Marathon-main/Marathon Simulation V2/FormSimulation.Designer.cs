﻿namespace Marathon_Simulation_V2
{
    partial class FormSimulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblBack = new System.Windows.Forms.LinkLabel();
            this.btnStart = new System.Windows.Forms.Button();
            this.panelStart = new System.Windows.Forms.Panel();
            this.panelFinish = new System.Windows.Forms.Panel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lblBack.LinkColor = System.Drawing.Color.Black;
            this.lblBack.Location = new System.Drawing.Point(10, 10);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(59, 21);
            this.lblBack.TabIndex = 0;
            this.lblBack.TabStop = true;
            this.lblBack.Text = "< Back";
            this.lblBack.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblBack_LinkClicked);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.White;
            this.btnStart.Location = new System.Drawing.Point(14, 356);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(651, 23);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // panelStart
            // 
            this.panelStart.BackColor = System.Drawing.Color.Black;
            this.panelStart.Location = new System.Drawing.Point(16, 50);
            this.panelStart.Name = "panelStart";
            this.panelStart.Size = new System.Drawing.Size(20, 100);
            this.panelStart.TabIndex = 2;
            // 
            // panelFinish
            // 
            this.panelFinish.BackColor = System.Drawing.Color.Red;
            this.panelFinish.Location = new System.Drawing.Point(641, 50);
            this.panelFinish.Name = "panelFinish";
            this.panelFinish.Size = new System.Drawing.Size(24, 100);
            this.panelFinish.TabIndex = 3;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FormSimulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(679, 392);
            this.Controls.Add(this.panelFinish);
            this.Controls.Add(this.panelStart);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblBack);
            this.Name = "FormSimulation";
            this.Text = "FormSimulation";
            this.Load += new System.EventHandler(this.FormSimulation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel lblBack;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Panel panelStart;
        private System.Windows.Forms.Panel panelFinish;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}