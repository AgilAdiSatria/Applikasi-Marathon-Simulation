﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Marathon_Simulation_V2
{
    public partial class MainForm : Form
    {
        private SqlCommand cmd;
        private SqlDataReader rd;

        Koneksi Konn = new Koneksi();

        private int eventID;
        public MainForm()
        {
            InitializeComponent();

            this.Text = "Marathon Simulation";
        }

        void LoadComboBox()
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();

            cmd = new SqlCommand("Select EventName From [Events]", conn);
            rd = cmd.ExecuteReader();

            while (rd.Read())
            {
                cbEvent.Items.Add(rd["EventName"]);
            }
            rd.Close();
            conn.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadComboBox();
        }

        private void btnPartList_Click(object sender, EventArgs e)
        {
            if(cbEvent.SelectedItem != null)
            {
                string eventName = cbEvent.SelectedItem.ToString();

                SqlConnection conn = Konn.GetConn();
                conn.Open();

                cmd = new SqlCommand("Select EventID From [Events] Where EventName = @EventName",conn);
                cmd.Parameters.AddWithValue("@EventName",eventName);

                eventID = (int)cmd.ExecuteScalar();

                conn.Close();

                this.Hide();
                FormParticipantList frmPartList = new FormParticipantList(eventID,eventName);
                frmPartList.Show();
            }
            else
            {
                MessageBox.Show("Harap Pilih Event Terlebih Dahulu");
            }
        }

        private void btnSimulation_Click(object sender, EventArgs e)
        {
            if (cbEvent.SelectedItem != null)
            {
                string eventName = cbEvent.SelectedItem.ToString();

                SqlConnection conn = Konn.GetConn();
                conn.Open();
                cmd = new SqlCommand("Select EventID From [Events] Where EventName = @EventName", conn);
                cmd.Parameters.AddWithValue("@EventName", eventName);

                eventID = (int)cmd.ExecuteScalar();
                conn.Close();

                this.Hide();
                FormSimulation frmSimulation = new FormSimulation(eventName,eventID);
                frmSimulation.Show();
            }
            else
            {
                MessageBox.Show("Harap Pilih Event Terlebih Dahulu");
            }
        }
    }
}
