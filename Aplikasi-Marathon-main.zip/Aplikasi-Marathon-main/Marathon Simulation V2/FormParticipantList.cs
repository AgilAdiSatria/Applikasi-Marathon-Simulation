﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Marathon_Simulation_V2
{
    public partial class FormParticipantList : Form
    {
        private SqlCommand cmd;
        private SqlDataAdapter da;
        private SqlDataReader rd;
        private DataSet ds;

        private int eventID;
        Koneksi Konn = new Koneksi();

        public FormParticipantList(int eventID,string eventName)
        {
            InitializeComponent();

            this.eventID = eventID;
            this.Text = $"Participants[{eventName}]";
        }

        public void LoadDataGridView()
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();

            cmd = new SqlCommand("Select ParticipantID,Name,Age,Speed From [Participants] Where EventID = @EventID", conn);
            cmd.Parameters.AddWithValue("@EventID", eventID);

            ds = new DataSet();
            da = new SqlDataAdapter(cmd);

            da.Fill(ds, "Participants");

            dgParticipant.DataSource = ds;
            dgParticipant.DataMember = "Participants";

            conn.Close();
        }

        private void FormParticipantList_Load(object sender, EventArgs e)
        {
            LoadDataGridView();
        }

        private void LinkBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            MainForm frmMain = new MainForm();
            frmMain.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
          if(dgParticipant.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedrow = dgParticipant.SelectedRows[0];

                int ParticipantID = Convert.ToInt32(selectedrow.Cells["ParticipantID"].Value);

                if(MessageBox.Show("Harap Pilih Data yang akan dihapus","Konfirmasi",MessageBoxButtons.YesNo,MessageBoxIcon.Question)== DialogResult.Yes)
                {
                    SqlConnection conn = Konn.GetConn();
                    conn.Open();

                    cmd = new SqlCommand("Delete [Participants] Where ParticipantID = @ParticipantID",conn);
                    cmd.Parameters.AddWithValue("@ParticipantID", ParticipantID);

                    cmd.ExecuteNonQuery();
                    LoadDataGridView();
                }
            }
          else
            {
                MessageBox.Show("Harap Pilih Data Yang akan dihapus Terlebih Dahulu");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgParticipant.SelectedRows.Count > 0)
            {
                DataGridViewRow SelectedRws = dgParticipant.SelectedRows[0];

                int ParticipantID = Convert.ToInt32(SelectedRws.Cells["ParticipantID"].Value);
                string Nama = SelectedRws.Cells["Name"].Value.ToString();
                int Age = Convert.ToInt32(SelectedRws.Cells["Age"].Value);
                decimal Speed = Convert.ToDecimal(SelectedRws.Cells["Speed"].Value);

                this.Hide();
                FormAddEditParticipant frmedit = new FormAddEditParticipant(eventID, Nama, Age, Speed, ParticipantID, "Edit");
                frmedit.Show();
            }
            else
            {
                MessageBox.Show("Harap Pilih Data yang Ingin Di edit Terlebih Dahulu");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormAddEditParticipant frmAdd = new FormAddEditParticipant(eventID, "Add");
            frmAdd.Show();
        }
    }
}
