﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Marathon_Simulation_V2
{
    public partial class FormResult : Form
    {
        public FormResult()
        {
            InitializeComponent();
        }

        public void ShowResults(List<(string name, TimeSpan time, int position)> results)
        {
            lstResults.Items.Clear();
            chartResults.Series.Clear();
            var series = chartResults.Series.Add("Race Results");

            foreach (var result in results)
            {
                lstResults.Items.Add($"{result.position}. {result.name} - Time: {result.time.Days} Days,{result.time.Hours} hours, {result.time.Minutes} min, {result.time.Seconds} sec");
                series.Points.AddXY(result.name, result.time.TotalSeconds);
            }

            series.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
        }

        private void lblBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            new MainForm().Show();
        }
    }
}
