﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Marathon_Simulation_V2
{
    public partial class FormSimulation : Form
    {
        private SqlCommand cmd;
        private SqlDataReader dr;
        private Timer timer;

        private List<int> speeds = new List<int>();
        private List<ProgressBar> progressBars = new List<ProgressBar>();
        private Dictionary<int, double> participantProgress = new Dictionary<int, double>();
        private List<string> participantNames = new List<string>();
        private double totalDistanceMeters;
        private double accelerationFactor = 1.0;

        private List<(string name, TimeSpan time, int position)> raceResults = new List<(string name, TimeSpan time, int position)>();
        private DateTime simulationStartTime;

        private int eventID;

        Koneksi Konn = new Koneksi();

        public FormSimulation(string eventName, int eventID)
        {
            InitializeComponent();
            this.eventID = eventID;
            this.Text = $"Simulation({eventName})";
        }

        void LoadParticipant()
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();

            cmd = new SqlCommand("SELECT Name, Speed FROM [Participants] WHERE EventID = @EventID", conn);
            cmd.Parameters.AddWithValue("@EventID", eventID);
            dr = cmd.ExecuteReader();

            int yOffsetBase = 70;
            int yOffsetIncrement = 50;
            int yOffset = yOffsetBase;
            int lastProgressBarBottom = 0;

            int index = 0;
            while (dr.Read())
            {
                string name = dr["Name"].ToString();
                int speed = Convert.ToInt32(dr["Speed"]);

                speeds.Add(speed);
                participantProgress[index] = 0;
                participantNames.Add(name);

                Label lbl = new Label
                {
                    Text = name,
                    AutoSize = true,
                    ForeColor = Color.Teal,
                    Font = new Font("Arial", 10, FontStyle.Bold),
                    Location = new Point(panelStart.Right + 20, yOffset - 20)
                };
                this.Controls.Add(lbl);

                ProgressBar pb = new ProgressBar
                {
                    Name = name,
                    Location = new Point(panelStart.Right + 20, yOffset),
                    Size = new Size(panelFinish.Left - panelStart.Right - 40, 23),
                    Maximum = 100
                };
                progressBars.Add(pb);
                this.Controls.Add(pb);

                lastProgressBarBottom = pb.Bottom;

                yOffset += yOffsetIncrement;
                index++;
            }

            dr.Close();
            conn.Close();

            panelStart.Height = lastProgressBarBottom - panelStart.Top;
            panelFinish.Height = lastProgressBarBottom - panelFinish.Top;

            btnStart.Location = new Point(14, lastProgressBarBottom + 10);
            this.Controls.Add(btnStart);

            int formHeight = lastProgressBarBottom + btnStart.Height + 30;
            this.ClientSize = new Size(this.ClientSize.Width, formHeight);
        }

        private void FormSimulation_Load(object sender, EventArgs e)
        {
            LoadParticipant();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            SqlConnection conn = Konn.GetConn();
            conn.Open();
            cmd = new SqlCommand("SELECT DistanceKm FROM [Events] WHERE EventID = @EventID", conn);
            cmd.Parameters.AddWithValue("@EventID", eventID);
            totalDistanceMeters = Convert.ToDouble(cmd.ExecuteScalar()) * 1000;
            conn.Close();

            simulationStartTime = DateTime.Now;

            timer = new Timer();
            timer.Interval = 100;
            timer.Tick += Timer_Tick;
            timer.Start();

            btnStart.Enabled = false;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            bool allFinished = true;

            for (int i = 0; i < progressBars.Count; i++)
            {
                double speedMetersPerSecond = speeds[i];
                participantProgress[i] += speedMetersPerSecond * accelerationFactor * (timer.Interval / 1000.0);

                double progressPercentage = Math.Min((participantProgress[i] / totalDistanceMeters) * 100, 100);
                progressBars[i].Value = (int)progressPercentage;

                // Cek jika peserta selesai
                if (participantProgress[i] < totalDistanceMeters)
                {
                    allFinished = false;
                }
                else if (!raceResults.Exists(r => r.name == participantNames[i]))
                {
                    double realTimeSeconds = totalDistanceMeters / speedMetersPerSecond;
                    TimeSpan realFinishTime = TimeSpan.FromSeconds(realTimeSeconds);

                    raceResults.Add((participantNames[i], realFinishTime, raceResults.Count + 1));
                }
            }

            if (allFinished)
            {
                timer.Stop();
                FormResult resultForm = new FormResult();
                resultForm.ShowResults(raceResults);
                resultForm.Show();
                this.Close();
            }
        }

        private void lblBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new MainForm().Show();
            this.Hide();
        }
    }
}
