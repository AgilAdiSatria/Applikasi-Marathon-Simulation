﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Marathon_Simulation_V2
{
    public partial class FormAddEditParticipant : Form
    {
        private SqlCommand cmd;

        private String eventName;
        private string mode;
        private int? ParticipantID;
        private int eventID;

        Koneksi Konn = new Koneksi();

        public FormAddEditParticipant(int eventID,string mode)
        {
            InitializeComponent();

            this.eventID = eventID;
            this.mode = mode;
            this.ParticipantID = null;

            if(mode == "Add")
            {
                btnSave.Text = "Add";
                this.Text = "Add";
            }
        }
        public FormAddEditParticipant(int eventID, string Name,int Age,decimal Speed,int ParticipantID,String mode)
        {
            InitializeComponent();

            this.mode = mode;
            this.ParticipantID = ParticipantID;
            this.eventID = eventID;

            if (mode == "Edit")
            {
                txtName.Text = Name;
                txtAge.Text = Age.ToString();
                txtSpeed.Text = Speed.ToString();

                btnSave.Text = "Edit";
                this.Text = "Edit";
            }
        }

        private void FormAddEditParticipant_Load(object sender, EventArgs e)
        {

        }

        private void LinkBack_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            FormParticipantList frmPartList = new FormParticipantList(eventID,eventName);
            frmPartList.Show();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(txtName.Text)|| String.IsNullOrEmpty(txtAge.Text)||  String.IsNullOrEmpty(txtSpeed.Text))
            {
                MessageBox.Show("Harap isi Semua Field Yang disediakan");
            }
            else
            {
                SqlConnection conn = Konn.GetConn();
                conn.Open();

                if(mode == "Add")
                {
                    cmd = new SqlCommand("Insert into [Participants] (Name,Age,Speed,EventID) Values (@Name,@Age,@Speed,@EventID)", conn);
                }
                else if ( mode == "Edit")
                {
                    if(MessageBox.Show("Apakah Anda Yakin Ingin MengUpdate Data ini","Konfirmasi",MessageBoxButtons.YesNo,MessageBoxIcon.Question)== DialogResult.Yes)
                    {
                        cmd = new SqlCommand("Update [Participants] set Name = @Name,Age = @Age,Speed = @Speed Where ParticipantID = @ParticipantID", conn);
                        cmd.Parameters.AddWithValue("@ParticipantID", ParticipantID);
                    }
                }
                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@EventID", eventID);
                cmd.Parameters.AddWithValue("@Age", Convert.ToInt32(txtAge.Text));
                cmd.Parameters.AddWithValue("@Speed", Convert.ToDecimal(txtSpeed.Text));
                cmd.ExecuteNonQuery();
                conn.Close();

                string Message = mode == "Add" ? "Data Berhasil Ditambahkan" : "Data Berhasil Di Update";
                MessageBox.Show(Message, "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();
                FormParticipantList frmPartList = new FormParticipantList(eventID, eventName);
                frmPartList.Show();
            }
        }

        private void txtAge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void txtSpeed_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar) && (!char.IsControl(e.KeyChar)) && e.KeyChar != ',')
            {
                e.Handled = true;
            }
            if(e.KeyChar == ',' && ((TextBox)sender).Text.Contains(","))
            {
                e.Handled = true;
            }
        }
    }
}
