﻿namespace Marathon_Simulation_V2
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSimulation = new System.Windows.Forms.Button();
            this.btnPartList = new System.Windows.Forms.Button();
            this.cbEvent = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSimulation
            // 
            this.btnSimulation.BackColor = System.Drawing.Color.White;
            this.btnSimulation.Location = new System.Drawing.Point(202, 77);
            this.btnSimulation.Name = "btnSimulation";
            this.btnSimulation.Size = new System.Drawing.Size(188, 23);
            this.btnSimulation.TabIndex = 9;
            this.btnSimulation.Text = "Simulation";
            this.btnSimulation.UseVisualStyleBackColor = false;
            this.btnSimulation.Click += new System.EventHandler(this.btnSimulation_Click);
            // 
            // btnPartList
            // 
            this.btnPartList.BackColor = System.Drawing.Color.White;
            this.btnPartList.Location = new System.Drawing.Point(8, 77);
            this.btnPartList.Name = "btnPartList";
            this.btnPartList.Size = new System.Drawing.Size(188, 23);
            this.btnPartList.TabIndex = 8;
            this.btnPartList.Text = "Participant List";
            this.btnPartList.UseVisualStyleBackColor = false;
            this.btnPartList.Click += new System.EventHandler(this.btnPartList_Click);
            // 
            // cbEvent
            // 
            this.cbEvent.FormattingEnabled = true;
            this.cbEvent.Location = new System.Drawing.Point(172, 41);
            this.cbEvent.Name = "cbEvent";
            this.cbEvent.Size = new System.Drawing.Size(163, 21);
            this.cbEvent.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Please select the events";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 21);
            this.label1.TabIndex = 5;
            this.label1.Text = "Marathon Simulation Event 2025";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 106);
            this.Controls.Add(this.btnSimulation);
            this.Controls.Add(this.btnPartList);
            this.Controls.Add(this.cbEvent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSimulation;
        private System.Windows.Forms.Button btnPartList;
        private System.Windows.Forms.ComboBox cbEvent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

